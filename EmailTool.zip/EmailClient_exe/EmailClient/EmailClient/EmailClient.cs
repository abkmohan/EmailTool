﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.Configuration;
using System.Security;
using System.DirectoryServices.AccountManagement;

namespace EmailClient
{
    public partial class EmailClient : Form
    {
        string exlTemplatepath = string.Empty;
        string smtpHost = string.Empty;
        int smtpPort = 0;
        string fromEmail = string.Empty;
        string smtpUser = string.Empty;
        string smtpPassword = string.Empty;
        string smtpDomain = string.Empty;

        public EmailClient()
        {
            InitializeComponent();
        }

        private void btnSendEmail_Click(object sender, EventArgs e)
        {

            int count = 0;
            if (exlTemplatepath == string.Empty)
                return;
            DataTable dt = new DataTable();
            try
            {
                dt = ImportExcel(exlTemplatepath);
                count = dt.Rows.Count;
                if (count == 0)
                    return;
                progressBar1.Maximum = count;
                progressBar1.Step = 1;
                Cursor.Current = Cursors.WaitCursor;
                foreach (DataRow dr in dt.Rows)
                {
                    if(!string.IsNullOrEmpty(Convert.ToString(dr["To"])))
                        SendEmail(dr);
                    progressBar1.PerformStep();
                }
                Cursor.Current = Cursors.Default;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        public DataTable ImportExcel(string filepath)
        {
            string sqlquery = @"Select * From [Email$]";
            DataSet ds = new DataSet();
            string constring = @"Provider=Microsoft.ACE.OLEDB.12.0;Mode=Read;Data Source=" + filepath + ";Extended Properties=\"Excel 12.0;HDR=YES;\"";
            OleDbConnection con = new OleDbConnection(constring + "");
            OleDbDataAdapter da = new OleDbDataAdapter(sqlquery, con);
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            return dt;
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try
            {
                openFileDialog1.InitialDirectory = Environment.CurrentDirectory;
                if (openFileDialog1.ShowDialog(this) == DialogResult.OK)
                {
                    string strfilename = openFileDialog1.FileName;
                    exlTemplatepath = tbTemplatePath.Text = strfilename;
                }
            }
            catch (IOException ex)
            {
                MessageBox.Show(ex.Message);
            }
            }

        private void EmailClient_Load(object sender, EventArgs e)
        {
            smtpHost = lblSMTPHost.Text = ConfigurationManager.AppSettings["SMTPHost"];
            smtpPort = Convert.ToInt32(ConfigurationManager.AppSettings["SMTPPort"]);
            lblSMTPPort.Text = smtpPort.ToString();
            fromEmail = lblFromEmail.Text = UserPrincipal.Current.EmailAddress; //ConfigurationManager.AppSettings["FromEmail"];
            smtpUser = lblSMTPUser.Text = System.Security.Principal.WindowsIdentity.GetCurrent().Name; //ConfigurationManager.AppSettings["SMTPUser"];
            smtpPassword = ConfigurationManager.AppSettings["SMTPPassword"];
            smtpDomain = ConfigurationManager.AppSettings["Domain"];
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            tbTemplatePath.Text = string.Empty;
            progressBar1.Value = 0;
        }

        private void SendEmail(DataRow dr)
        {
            try
            {

                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient(smtpHost);
                mail.From = new MailAddress(fromEmail);
                mail.To.Add(dr["To"].ToString());
                if(dr["CC"].ToString().Trim() != string.Empty)
                    mail.CC.Add(dr["CC"].ToString());
                if (dr["BCC"].ToString().Trim() != string.Empty)
                    mail.Bcc.Add(dr["BCC"].ToString());
                mail.Subject = dr["Subject"].ToString();
                mail.Body = dr["Body"].ToString();

                System.Net.Mail.Attachment attachment;
                attachment = new System.Net.Mail.Attachment(dr["Attachment"].ToString());
                mail.Attachments.Add(attachment);

                SmtpServer.Port = smtpPort;
                //SmtpServer.Credentials = new System.Net.NetworkCredential(smtpUser, smtpPassword, "EMEA");
                SmtpServer.UseDefaultCredentials = true;
                SmtpServer.EnableSsl = false;
                SmtpServer.Send(mail);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
 }
